A Pen created at CodePen.io. You can find this one at https://codepen.io/byee0992/pen/ZwJeqe.

 Practice project pen using Udacity Google Maps Javascript API course. This map shows real estate listings in New York and has an interactive info window that show the street view of each listing.